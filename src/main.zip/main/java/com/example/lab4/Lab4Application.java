package com.example.lab4;

import com.example.lab4.model.Courses;
import com.example.lab4.model.Operators;
import com.example.lab4.repository.CoursesRepository;
import com.example.lab4.repository.OperatorsRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Lab4Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab4Application.class, args);
	}

	@Bean
	public CommandLineRunner initData(CoursesRepository coursesRepository, OperatorsRepository operatorsRepository) {
		return args -> {
			// Add Courses
			if (coursesRepository.count() == 0) {
				coursesRepository.save(new Courses(null, "Java Standard Edition", "Основы программирования на Java", 200));
				coursesRepository.save(new Courses(null, "Web Technologies", "Разработка веб-приложений", 250));
				coursesRepository.save(new Courses(null, "Python Programming Language", "Введение в Python", 180));
				coursesRepository.save(new Courses(null, "Java Pro", "Продвинутое программирование на Java", 350));
				coursesRepository.save(new Courses(null, "UX/UI Design", "Основы дизайна пользовательских интерфейсов", 220));
				coursesRepository.save(new Courses(null, "Django Framework", "Веб-разработка с Django", 300));
				System.out.println("Initial courses added.");
			}

			// Add Operators
			if (operatorsRepository.count() == 0) {
				operatorsRepository.save(new Operators(null, "Едил", "Бакенов", "Продажа"));
				operatorsRepository.save(new Operators(null, "Жорже", "Мендеш", "Рекрутинг"));
				operatorsRepository.save(new Operators(null, "Ержан", "Болатов", "Маркетинг"));
				operatorsRepository.save(new Operators(null, "Сержан", "Арманов", "ИТ"));
				operatorsRepository.save(new Operators(null, "Флорентино", "Перес", "Администрация"));
				System.out.println("Initial operators added.");
			}
		};
	}
}