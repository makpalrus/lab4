package com.example.lab4.controller;

import com.example.lab4.model.ApplicationRequest;
import com.example.lab4.model.Courses;
import com.example.lab4.model.Operators;
import com.example.lab4.service.ApplicationRequestService;
import com.example.lab4.service.CoursesService;
import com.example.lab4.service.OperatorsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/requests")
public class ApplicationRequestController {

    @Autowired
    private ApplicationRequestService service;
    @Autowired
    private CoursesService coursesService;
    @Autowired
    private OperatorsService operatorsService;

    @GetMapping
    public String getAllRequests(Model model) {
        List<ApplicationRequest> requests = service.getAllRequests();
        model.addAttribute("requests", requests);
        model.addAttribute("filter", "all");
        return "index";
    }

    @GetMapping("/pending")
    public String getPendingRequests(Model model) {
        List<ApplicationRequest> requests = service.getPendingRequests();
        model.addAttribute("requests", requests);
        model.addAttribute("filter", "pending");
        return "index";
    }

    @GetMapping("/processed")
    public String getProcessedRequests(Model model) {
        List<ApplicationRequest> requests = service.getProcessedRequests();
        model.addAttribute("requests", requests);
        model.addAttribute("filter", "processed");
        return "index";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("request", new ApplicationRequest());
        List<Courses> courses = coursesService.getAllCourses();
        model.addAttribute("courses", courses);
        return "add";
    }

    @PostMapping("/add")
    public String addRequest(@ModelAttribute ApplicationRequest request, @RequestParam("courseId") Long courseId) {
        Courses selectedCourse = coursesService.getCourseById(courseId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid course ID: " + courseId));
        request.setCourse(selectedCourse);
        request.setHandled(false);
        service.saveRequest(request);
        return "redirect:/requests";
    }

    @GetMapping("/{id}")
    public String viewRequest(@PathVariable Long id, Model model) {
        ApplicationRequest request = service.getRequestById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid request ID: " + id));
        model.addAttribute("request", request);
        model.addAttribute("assignedOperators", request.getOperators());
        return "details";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        ApplicationRequest request = service.getRequestById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid request ID: " + id));
        model.addAttribute("request", request);
        List<Courses> courses = coursesService.getAllCourses();
        model.addAttribute("courses", courses);


        List<Operators> allOperators = operatorsService.getAllOperators();
        model.addAttribute("allOperators", allOperators);
        model.addAttribute("assignedOperatorIds", request.getOperators().stream()
                .map(Operators::getId)
                .collect(Collectors.toSet()));

        return "edit";
    }

    @PostMapping("/edit/{id}")
    public String updateRequest(@PathVariable Long id, @ModelAttribute ApplicationRequest request,
                                @RequestParam("courseId") Long courseId,
                                @RequestParam(value = "operatorIds", required = false) List<Long> operatorIds, // Принимаем ID выбранных операторов
                                RedirectAttributes redirectAttributes) {
        ApplicationRequest existingRequest = service.getRequestById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid request ID: " + id));


        existingRequest.setUserName(request.getUserName());
        existingRequest.setCommentary(request.getCommentary());
        existingRequest.setPhone(request.getPhone());


        Courses selectedCourse = coursesService.getCourseById(courseId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid course ID: " + courseId));
        existingRequest.setCourse(selectedCourse);

        try {
            service.updateOperatorsForRequest(id, operatorIds);
            service.saveRequest(existingRequest);

            redirectAttributes.addFlashAttribute("successMessage", "Заявка и операторы успешно обновлены.");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }

        return "redirect:/requests/" + id;
    }

    @GetMapping("/delete/{id}")
    public String deleteRequest(@PathVariable Long id) {
        service.deleteRequest(id);
        return "redirect:/requests";
    }

   @GetMapping("/removeOperator/{requestId}/{operatorId}")
    public String removeOperatorFromRequest(@PathVariable Long requestId, @PathVariable Long operatorId,
                                            RedirectAttributes redirectAttributes) {
        try {
            service.removeOperatorFromRequest(requestId, operatorId);
            redirectAttributes.addFlashAttribute("successMessage", "Оператор успешно удален из заявки.");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/requests/" + requestId;
    }
}