package com.example.lab4.service;

import com.example.lab4.model.Courses;
import com.example.lab4.repository.CoursesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CoursesService {

    @Autowired
    private CoursesRepository repository;

    public List<Courses> getAllCourses() {
        return repository.findAll();
    }

    public Optional<Courses> getCourseById(Long id) {
        return repository.findById(id);
    }

    public Courses saveCourse(Courses course) {
        return repository.save(course);
    }

    public void deleteCourse(Long id) {
        repository.deleteById(id);
    }
}