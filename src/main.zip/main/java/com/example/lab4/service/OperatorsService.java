package com.example.lab4.service;

import com.example.lab4.model.Operators;
import com.example.lab4.repository.OperatorsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OperatorsService {

    @Autowired
    private OperatorsRepository repository;

    public List<Operators> getAllOperators() {
        return repository.findAll();
    }

    public Optional<Operators> getOperatorById(Long id) {
        return repository.findById(id);
    }

    public Operators saveOperator(Operators operator) {
        return repository.save(operator);
    }

    public void deleteOperator(Long id) {
        repository.deleteById(id);
    }

    public List<Operators> getOperatorsByDepartment(String department) {
        return repository.findByDepartment(department);
    }
}