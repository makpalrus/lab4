package com.example.lab4.service;

import com.example.lab4.model.ApplicationRequest;
import com.example.lab4.model.Courses;
import com.example.lab4.model.Operators;
import com.example.lab4.repository.ApplicationRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.HashSet; // Import HashSet

@Service
public class ApplicationRequestService {

    @Autowired
    private ApplicationRequestRepository repository;

    @Autowired
    private CoursesService coursesService;

    @Autowired
    private OperatorsService operatorsService;

    public List<ApplicationRequest> getAllRequests() {
        return repository.findAll();
    }

    public List<ApplicationRequest> getPendingRequests() {
        return repository.findByHandledFalse();
    }

    public List<ApplicationRequest> getProcessedRequests() {
        return repository.findByHandledTrue();
    }

    public Optional<ApplicationRequest> getRequestById(Long id) {
        return repository.findById(id);
    }

    @Transactional
    public ApplicationRequest saveRequest(ApplicationRequest request) {
        if (request.getCourse() != null && request.getCourse().getId() != null) {
            coursesService.getCourseById(request.getCourse().getId())
                    .ifPresent(request::setCourse);
        }
        return repository.save(request);
    }

    public void deleteRequest(Long id) {
        repository.deleteById(id);
    }

    @Transactional
    public ApplicationRequest updateOperatorsForRequest(Long requestId, List<Long> newOperatorIds) {
        ApplicationRequest request = repository.findById(requestId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid request ID: " + requestId));

        Set<Operators> currentOperators = request.getOperators();
        boolean wasHandled = request.getHandled(); // Запоминаем текущий статус

        Set<Operators> operatorsToAssign = new HashSet<>();
        if (newOperatorIds != null) {
            for (Long operatorId : newOperatorIds) {
                operatorsService.getOperatorById(operatorId)
                        .ifPresent(operatorsToAssign::add);
            }
        }

        request.setOperators(operatorsToAssign);

        if (!operatorsToAssign.isEmpty() && !wasHandled) {
            request.setHandled(true);
        } else if (operatorsToAssign.isEmpty() && wasHandled) {
            request.setHandled(false);
        }

        return repository.save(request);
    }
    @Transactional
    public ApplicationRequest removeOperatorFromRequest(Long requestId, Long operatorId) {
        ApplicationRequest request = repository.findById(requestId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid request ID: " + requestId));
        Operators operatorToRemove = operatorsService.getOperatorById(operatorId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid operator ID: " + operatorId));

        request.getOperators().remove(operatorToRemove);

        if (request.getOperators().isEmpty()) {
            request.setHandled(false);
        }
        return repository.save(request);
    }


    public Set<Operators> getOperatorsForRequest(Long requestId) {
        ApplicationRequest request = repository.findById(requestId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid request ID: " + requestId));
        return request.getOperators();
    }
}